package model;

public class Reserva extends Contenedor {

	public Reserva(int capacidad, int contenido) {
		super(capacidad, contenido);
	}
	public Reserva() {
		
	}
	
}
	
