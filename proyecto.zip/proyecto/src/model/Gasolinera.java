package model;

public class Gasolinera {

}
